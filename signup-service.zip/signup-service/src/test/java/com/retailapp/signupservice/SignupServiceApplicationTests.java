package com.retailapp.signupservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignupServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
